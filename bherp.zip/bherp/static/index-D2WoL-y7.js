import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-B566OOFS.js";import"./index-Crf1R5fk.js";export{m as default};
